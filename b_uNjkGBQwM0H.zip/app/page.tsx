"use client"

import { useEffect } from "react"
import AOS from "aos"
import "aos/dist/aos.css"
import { BentoCard } from "@/components/bento-card"
import { Mail, ArrowRight } from "lucide-react"

export default function Home() {
  useEffect(() => {
    AOS.init({
      duration: 800,
      once: true,
      easing: "ease-out-cubic",
    })
  }, [])

  return (
    <main className="max-w-5xl w-full mx-auto grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5 auto-rows-max">
      {/* Hero Section */}
      <BentoCard
        className="md:col-span-3 flex flex-col justify-center items-start overflow-hidden relative"
        data-aos="fade-down"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/80 text-[0.7rem] sm:text-xs font-medium text-slate-300 mb-6 shadow-sm">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          Current Status: Building Feyntech
        </div>

        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400 mb-3">
          Henry
        </h1>
        <p className="text-base sm:text-lg text-slate-400 font-light">
          Grade 9 Developer <span className="text-slate-600 px-1">&</span> Logic Designer
        </p>
      </BentoCard>

      {/* Feyntech Project */}
      <BentoCard
        className="md:col-span-2 md:row-span-1 flex flex-col justify-center group relative overflow-hidden"
        data-aos="fade-up"
        data-aos-delay="100"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col items-start">
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-3xl font-semibold text-slate-100">Feyntech</h2>
            <span className="px-2 py-1 bg-indigo-500/20 text-indigo-300 text-[0.65rem] uppercase tracking-wider font-bold rounded-md">
              Logic Engine
            </span>
          </div>
          <p className="text-slate-400 text-base mb-6 max-w-md leading-relaxed">
            An AI-powered logic analyzer that uses the{" "}
            <strong className="text-slate-300">Feynman Technique</strong> to break down complex
            concepts. It identifies knowledge gaps by analyzing how simply you can explain a topic.
          </p>
          <a
            href="https://agent-69ed91804039c53c08316a7e--feyntech.netlify.app/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-6 py-2.5 rounded-full text-sm transition-all hover:scale-[1.05] active:scale-95"
          >
            Launch App
            <ArrowRight className="w-4 h-4 ml-2" />
          </a>
        </div>
      </BentoCard>

      {/* Discord Bot */}
      <BentoCard
        className="md:col-span-1 md:row-span-2 flex flex-col justify-between"
        data-aos="fade-left"
        data-aos-delay="200"
      >
        <div>
          <div className="w-12 h-12 rounded-2xl bg-[#5865F2]/10 border border-[#5865F2]/20 text-[#5865F2] flex items-center justify-center mb-5">
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286z" />
            </svg>
          </div>
          <h2 className="text-xl font-semibold text-slate-100 mb-2">Feyntech Bot</h2>
          <p className="text-slate-400 text-sm leading-relaxed mb-4">
            A Discord-native port of the Feyntech engine. Transforms study groups into active recall
            sessions by analyzing explanations and identifying gaps.
          </p>
          <div className="p-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-[0.7rem] font-mono text-slate-500">
            {"// Logic Loop"}
            <br />
            {"User -> Explain(Concept)"}
            <br />
            {"Bot -> Analyze(Gaps)"}
            <br />
            {"Bot -> Challenge(Simplify)"}
          </div>
        </div>
        <div className="mt-6 pt-4 border-t border-slate-700/50">
          <span className="text-xs font-mono text-slate-500 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> Active Deployment
          </span>
        </div>
      </BentoCard>

      {/* Arsenal */}
      <BentoCard
        className="md:col-span-1 flex flex-col justify-between"
        data-aos="fade-up"
        data-aos-delay="300"
      >
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-widest mb-4">
          Arsenal
        </h3>
        <div className="flex flex-wrap gap-1.5">
          <span className="px-2 py-1 bg-sky-500/10 text-sky-400 border border-sky-500/20 rounded-md text-[0.7rem] font-medium">
            React
          </span>
          <span className="px-2 py-1 bg-teal-500/10 text-teal-400 border border-teal-500/20 rounded-md text-[0.7rem] font-medium">
            Tailwind
          </span>
          <span className="px-2 py-1 bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 rounded-md text-[0.7rem] font-medium">
            Python
          </span>
          <span className="px-2 py-1 bg-pink-500/10 text-pink-400 border border-pink-500/20 rounded-md text-[0.7rem] font-medium">
            Design
          </span>
        </div>
      </BentoCard>

      {/* Connect */}
      <BentoCard
        className="md:col-span-1 flex flex-col justify-between"
        data-aos="fade-up"
        data-aos-delay="400"
      >
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-widest mb-4">
          Connect
        </h3>
        <div className="space-y-4">
          <a
            href="mailto:akindhenry93@gmail.com"
            className="contact-link flex items-center gap-3"
          >
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Mail className="w-4 h-4" />
            </div>
            <span className="text-xs text-slate-300">akindhenry93@gmail.com</span>
          </a>
          <a
            href="https://discord.gg/JYr5CDTng"
            target="_blank"
            rel="noopener noreferrer"
            className="contact-link flex items-center gap-3"
          >
            <div className="p-2 rounded-lg bg-[#5865F2]/10 text-[#5865F2] border border-[#5865F2]/20">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286z" />
              </svg>
            </div>
            <span className="text-xs text-slate-300">Join Discord</span>
          </a>
        </div>
      </BentoCard>
    </main>
  )
}
