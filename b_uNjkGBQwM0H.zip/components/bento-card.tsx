"use client"

import { cn } from "@/lib/utils"

interface BentoCardProps {
  children: React.ReactNode
  className?: string
  "data-aos"?: string
  "data-aos-delay"?: string
}

export function BentoCard({ children, className, ...props }: BentoCardProps) {
  return (
    <section
      className={cn(
        "bento-card",
        className
      )}
      {...props}
    >
      {children}
    </section>
  )
}
